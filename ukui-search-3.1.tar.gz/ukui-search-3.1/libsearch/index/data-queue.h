#ifndef DATAQUEUE_H
#define DATAQUEUE_H


class DataQueue
{
public:
    DataQueue();
};

#endif // DATAQUEUE_H
