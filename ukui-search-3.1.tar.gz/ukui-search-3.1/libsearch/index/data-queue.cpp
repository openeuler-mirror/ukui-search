#include "data-queue.h"

DataQueue::DataQueue()
{

}
