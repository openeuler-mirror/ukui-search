/*
 * temporary use friso.ini, it should be removed in the future.
 * MouseZhangZh
*/
#include "friso/src/friso_API.h"
#include "friso/src/friso.h"
#include "friso/src/friso_ctype.h"

//int friso_test(int argc, char **argv);
int friso_test();
